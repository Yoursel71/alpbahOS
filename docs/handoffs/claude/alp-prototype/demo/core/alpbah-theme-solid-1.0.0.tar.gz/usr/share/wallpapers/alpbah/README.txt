placeholder wallpaper metadata, not a real image
